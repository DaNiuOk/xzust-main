<style lang="scss" scoped>
.banner {
    img {
        width: 100%;
    }
}
</style>
<template>
    <div class="banner">
        <img src="../../assets/topbackg.jpg" alt="">
    </div>
</template>